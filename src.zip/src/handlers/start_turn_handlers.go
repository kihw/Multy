package handlers

import (
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/kihw/multy/src/services"
)

// StartTurnServiceHandler gère les requêtes liées à StartTurnService.
type StartTurnServiceHandler struct {
	StartTurnService *services.StartTurnService
}

// NewStartTurnServiceHandler crée un nouveau gestionnaire pour StartTurnService.
func NewStartTurnServiceHandler(startTurnService *services.StartTurnService) *StartTurnServiceHandler {
	return &StartTurnServiceHandler{
		StartTurnService: startTurnService,
	}
}

// StartService démarre StartTurnService.
func (h *StartTurnServiceHandler) StartService(c *gin.Context) {
	if h.StartTurnService.IsRunning() {
		c.JSON(http.StatusBadRequest, gin.H{"message": "Service is already running"})
		return
	}

	h.StartTurnService.Start()
	c.JSON(http.StatusOK, gin.H{"message": "StartTurnService started"})
}

// StopService arrête StartTurnService.
func (h *StartTurnServiceHandler) StopService(c *gin.Context) {
	if !h.StartTurnService.IsRunning() {
		c.JSON(http.StatusBadRequest, gin.H{"message": "Service is not running"})
		return
	}

	h.StartTurnService.Stop()
	c.JSON(http.StatusOK, gin.H{"message": "StartTurnService stopped"})
}
