package services

import (
	"log"
	"unsafe"

	"golang.org/x/sys/windows"
)

var (
	kernel32 = windows.NewLazySystemDLL("kernel32.dll")

	procSetWinEventHook  = user32.NewProc("SetWinEventHook")
	procUnhookWinEvent   = user32.NewProc("UnhookWinEvent")
	procGetMessage       = user32.NewProc("GetMessageW")
	procTranslateMessage = user32.NewProc("TranslateMessage")
	procDispatchMessage  = user32.NewProc("DispatchMessageW")
)

const (
	EVENT_SYSTEM_FOREGROUND = 0x0003 // Événement lorsque la fenêtre de premier plan change
	WINEVENT_OUTOFCONTEXT   = 0x0000 // Pour ne pas injecter dans un autre processus
)

type MSG struct {
	HWnd    windows.Handle
	Message uint32
	WParam  uintptr
	LParam  uintptr
	Time    uint32
	Pt      POINT
}

type POINT struct {
	X, Y int32
}
type HWND windows.Handle
type HWINEVENTHOOK windows.Handle

// StartTurnService gère le service qui surveille les messages d'une fenêtre existante.
type StartTurnService struct {
	hwnd        HWND          // Handle de la fenêtre surveillée
	running     bool          // Indicateur de service en cours d'exécution
	stopChan    chan struct{} // Canal pour arrêter le service
	hook        HWINEVENTHOOK // Hook pour les événements Windows
	windowTitle string        // Titre de la fenêtre à surveiller
}

// NewStartTurnService crée une nouvelle instance du service.
func NewStartTurnService(windowTitle string) *StartTurnService {
	return &StartTurnService{
		windowTitle: windowTitle,
	}
}

// Start démarre le service et écoute les événements sur la fenêtre existante.
func (sts *StartTurnService) Start() {
	if sts.running {
		log.Println("Service is already running.")
		return
	}

	hwnd, err := sts.findWindowByTitle(sts.windowTitle)
	if err != nil {
		log.Fatalf("Could not find window: %v", err)
	}
	sts.hwnd = hwnd

	log.Printf("Found window with handle: %d", hwnd)

	// Met en place un hook d'événements pour la fenêtre trouvée
	hook, _, err := procSetWinEventHook.Call(
		EVENT_SYSTEM_FOREGROUND,                // Événement : changement de la fenêtre au premier plan
		EVENT_SYSTEM_FOREGROUND,                // Même événement pour début et fin de plage
		0,                                      // Pas besoin de DLL, utilise le processus actuel
		windows.NewCallback(sts.eventCallback), // Fonction de rappel
		0, 0,                                   // Process et thread ID à surveiller (0 = global)
		WINEVENT_OUTOFCONTEXT, // Contexte de hook sans injection
	)
	if hook == 0 {
		log.Fatalf("Failed to set event hook: %v", err)
	}
	sts.hook = HWINEVENTHOOK(hook)

	log.Printf("Hook set for window %d, listening for events...", hwnd)

	sts.stopChan = make(chan struct{})
	sts.running = true
	go sts.monitorEvents()
	log.Println("Service started, monitoring for specific Windows messages.")
}

// Stop arrête le service et enlève le hook des événements.
func (sts *StartTurnService) Stop() {
	if !sts.running {
		log.Println("Service is not running.")
		return
	}

	close(sts.stopChan)
	sts.running = false

	// Supprime le hook d'événement Windows
	procUnhookWinEvent.Call(uintptr(sts.hook))

	log.Println("Service stopped.")
}

// run exécute la logique du service en arrière-plan.
func (sts *StartTurnService) run() {
	// Votre logique de traitement des messages ou autre ici.
	<-sts.stopChan // Attendre l'arrêt
}

// IsRunning retourne true si le service est en cours d'exécution.
func (sts *StartTurnService) IsRunning() bool {
	sts.mutex.Lock()
	defer sts.mutex.Unlock()
	return sts.running
}

// monitorEvents écoute les événements dans une boucle de messages Windows.
func (sts *StartTurnService) monitorEvents() {
	var msg MSG
	for {
		select {
		case <-sts.stopChan:
			return
		default:
			ret, _, _ := procGetMessage.Call(uintptr(unsafe.Pointer(&msg)), 0, 0, 0)
			if ret == 0 {
				break
			}
			procTranslateMessage.Call(uintptr(unsafe.Pointer(&msg)))
			procDispatchMessage.Call(uintptr(unsafe.Pointer(&msg)))
		}
	}
}

// eventCallback est la fonction de rappel lorsqu'un événement est intercepté.
func (sts *StartTurnService) eventCallback(hWinEventHook HWINEVENTHOOK, event uint32, hwnd HWND, idObject, idChild, dwEventThread, dwmsEventTime uint32) uintptr {
	if hwnd == sts.hwnd {
		log.Printf("Event detected on the window %d: event type: %d", hwnd, event)
	}
	return 0
}

// findWindowByTitle recherche une fenêtre par son titre.
func (sts *StartTurnService) findWindowByTitle(windowTitle string) (HWND, error) {
	titleUTF16, err := windows.UTF16PtrFromString(windowTitle)
	if err != nil {
		return 0, err
	}

	hwnd, _, _ := procFindWindow.Call(0, uintptr(unsafe.Pointer(titleUTF16)))
	if hwnd == 0 {
		return 0, windows.GetLastError()
	}

	return HWND(hwnd), nil
}
